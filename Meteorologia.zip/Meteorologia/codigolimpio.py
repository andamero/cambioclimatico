taxrate = 0.2  # Tasa de impuesto


def tax(Price):
    return Price * taxrate  # Calcula el impuesto a partir del precio


def sum_prices(a, b, c, d):
    return a + b + c + d  # Suma los precios proporcionados


total = sum_prices(100, 200, 300, 400)
tax = tax(total)
print("El precio final es ", total + tax)  # Muestra el precio final
