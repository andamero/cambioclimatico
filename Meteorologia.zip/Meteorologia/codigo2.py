# Constantes
GRYFFINDOR_POINTS = 20
HERMIONE_POINTS = 25
RON_POINTS = 18
DRACO_POINTS = 30


def calc_points(*args):
    """Calcula el total de puntos obtenidos por la casa"""
    return sum(args)


def print_points(house_name, points):
    """Muestra los puntos obtenidos por la casa"""
    print(f"{house_name} tiene {points} puntos")


def sort_students():
    gryffindor = calc_points(GRYFFINDOR_POINTS, HERMIONE_POINTS, RON_POINTS)
    slytherin = calc_points(DRACO_POINTS)

    print_points("Gryffindor", gryffindor)
    print_points("Slytherin", slytherin)


sort_students()
