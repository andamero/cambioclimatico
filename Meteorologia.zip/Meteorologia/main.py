#importar las bibliotecas necesarias
import discord
from discord.ext import commands
import pyttsx3
import requests


#iniciar el bot
intents = discord.Intents.default() 
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)


@bot.command()
async def start(ctx):
    await ctx.send("hola mundo estoy  aca")

engine = pyttsx3.init()


def get_weather(city: str) -> str:
    base_url = f"https://wttr.in/{city}?format=%c+%t"
    response = requests.get(base_url)

    if response.status_code == 200:
        return response.text.strip()
    else:
        return "No se pudo obtener la información del clima. Por favor, inténtalo más tarde."


@bot.command()
async def weather(ctx, *, city: str):
    weather_info = get_weather(city)
    await ctx.send(f"Clima en {city}: {weather_info}")   
    speak(weather_info)


def get_fact() -> str:
    base_url = "https://uselessfacts.jsph.pl/random.json"
    response = requests.get(base_url)

    if response.status_code == 200:
        data = response.json()
        return data.get("text", "No se pudo obtener el dato.")
    else:
        return "No se pudo obtener la información del clima. Por favor, inténtalo más tarde."


def speak(text: str):
    engine.say(text)
    engine.runAndWait()

@bot.command()
async def fact(ctx):
    fact_info = get_fact()
    await ctx.send(f"aqui tienes un dato curioso: {fact_info}")   
    speak(fact_info)

#iniciar  el bot
bot.run("MTM1MDY4NzE4NTM3NjEyMDk2NA.Gd1cCU.M0DMaODawT5SyQ4PzKs2angE2iL5DhEbGiYZxs")
